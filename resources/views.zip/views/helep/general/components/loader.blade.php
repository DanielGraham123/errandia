<section id="loader-section">
    <div class="loader">
        <div class="spin"></div>
    </div>
</section>
